
public class Constants
{
    public static int maxNumberGenerated = 100;
    public static int queueSize = 4;
    public static int sleepTimeConsumer = 350;
    public static int sleepTimeProducer = 180;
    public static int numberOfConsumers = 4;
    public static int numberOfProducer = 7;
}
