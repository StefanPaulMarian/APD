public interface Generator
{
    int next();
}
