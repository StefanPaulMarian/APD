public interface Generator
{
    public int next();
}
