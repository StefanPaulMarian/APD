public class Constants
{
    public static final int maxNumbers = 100;
}
