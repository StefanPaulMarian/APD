public class Constants
{
    public static final double[] myVect = { 1.9, 2.2, 3.4, 0.5, 3.5, 23.8, 14, -80.5, 12, -10, 3.5, -14, 3.5, 42, -18};
    public static final int MASTER = 0;
    public static final int PROCESSORS_NUMBER = 4;
}
